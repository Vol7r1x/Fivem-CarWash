Lang = {
  ['wash_car']         = ' [~r~E~s~] WASH MENU ',
  ["be_in_car"]		   = " YOU MUST BE IN CAR ",
    
  ['wash_menu']         = ' WASH MENU ',
  ['wash_car1']         = ' STANDARD WASH ',
  ['wash_car2']         = ' PREMIUM WASH ',
  ["premium_wash"]		=	"You vehicle was washed, and removed any scratch !",
  ["standard_wash"]		=	"You vehicle was washed !",
  ["no_money"]			=	"You don't have enought money !",
  ["too_damage"]		=	"You vehicle is too damaged to wash and remove scratch, Go to mechanic !",
}
